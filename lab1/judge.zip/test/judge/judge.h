#include <vector>
#include <string>
#include <map>
#include "trans.h"

using std::map;
using std::string;
using std::vector;

void initCSV(const int &threads);
void loadTrans(const int &threads);
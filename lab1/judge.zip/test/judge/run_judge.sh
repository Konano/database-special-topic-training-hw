pip install -r requirements.txt
make
./main 4
python compare_outputs.py 4
